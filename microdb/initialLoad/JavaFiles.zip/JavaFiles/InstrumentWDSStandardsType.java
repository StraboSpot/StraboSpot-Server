package org.strabospot.datatypes;

public class InstrumentWDSStandardsType {
    public String element;
    public String crystalType;
    public String standardName;

    public String getElement() {
        return element;
    }

    public void setElement(String element) {
        this.element = element;
    }

    public String getCrystalType() {
        return crystalType;
    }

    public void setCrystalType(String crystalType) {
        this.crystalType = crystalType;
    }

    public String getStandardName() {
        return standardName;
    }

    public void setStandardName(String standardName) {
        this.standardName = standardName;
    }
}
