package org.strabospot.datatypes;

public class GrainBoundaryMorphologyType {
    public String type;

    public GrainBoundaryMorphologyType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
