package org.strabospot.datatypes;

public class InstrumentDetectorType {
    public String detectorType;
    public String detectorMake;
    public String detectorModel;

    public String getDetectorType() {
        return detectorType;
    }

    public void setDetectorType(String detectorType) {
        this.detectorType = detectorType;
    }

    public String getDetectorMake() {
        return detectorMake;
    }

    public void setDetectorMake(String detectorMake) {
        this.detectorMake = detectorMake;
    }

    public String getDetectorModel() {
        return detectorModel;
    }

    public void setDetectorModel(String detectorModel) {
        this.detectorModel = detectorModel;
    }
}
