package org.strabospot.datatypes;

import javafx.geometry.Point2D;

public class VertexHandleType {
    public Point2D originalCenter;
}
