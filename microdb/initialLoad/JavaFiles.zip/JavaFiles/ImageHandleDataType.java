package org.strabospot.datatypes;

import javafx.geometry.Point2D;

public class ImageHandleDataType {

    public Point2D originalPosition;
    public Point2D oppositePostion;
    public Double originalImageSize;


}
