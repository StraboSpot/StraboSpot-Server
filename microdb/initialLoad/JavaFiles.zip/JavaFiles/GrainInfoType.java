package org.strabospot.datatypes;

public class GrainInfoType {
    public GrainSizeType[] grainSizeInfo;
    public GrainShapeType[] grainShapeInfo;
    public GrainOrientationType[] grainOrientationInfo;
    public String grainSizeNotes;
    public String grainShapeNotes;
    public String grainOrientationNotes;

}
