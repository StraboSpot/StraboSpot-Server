This georeferenced image was downloaded from the USGS/AASG National Geologic Map Database, on Thu Jun 24 01:27:48 2021 (GMT).
Georeferencing and projection information are provided in the USGS_MF-2340_1.tif.aux.xml file (see also the USGS_MF-2340_1.tif.txt).

TITLE = Geologic map of the Frisco quadrangle, Summit County, Colorado
AUTHOR(S) = Kellogg, K.S., Bartos, P.J., and Williams, C.L.
PUBLISHER = U.S. Geological Survey
SERIES NAME = Miscellaneous Field Studies Map
SERIES NUMBER = MF-2340
PUBLICATION DATE = 2002
SCALE = 1:24,000
URL = /Prodesc/proddesc_54462.htm
